// ── Bekezdés háttérszín helper ────────────────────────────────
// Közvetlenül ProseMirror tranzakcióval állítja be a háttérszínt,
// mert a Tiptap Extension addCommands nem regisztrálódik megbízhatóan
export function applyParaBg(editor, color) {
  const { state, view } = editor;
  const { tr, selection } = state;
  const { from, to } = selection;
  let changed = false;

  state.doc.nodesBetween(from, to, (node, pos) => {
    if (node.type.name === 'paragraph' || node.type.name === 'heading') {
      tr.setNodeMarkup(pos, undefined, {
        ...node.attrs,
        backgroundColor: color || null,
      });
      changed = true;
    }
  });

  if (changed) view.dispatch(tr);
}